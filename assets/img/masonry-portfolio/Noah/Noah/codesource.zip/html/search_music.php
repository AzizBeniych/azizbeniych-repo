<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;
use Aws\DynamoDb\Exception\DynamoDbException;

// Initialize the DynamoDB client
$dynamoDb = new DynamoDbClient([
    'region'  => 'us-east-1',
    'version' => 'latest',
]);

// Retrieve search criteria
$title = isset($_GET['title']) ? $_GET['title'] : null;
$year = isset($_GET['year']) ? $_GET['year'] : null;
$artist = isset($_GET['artist']) ? $_GET['artist'] : null;

// Constructing a filter expression for the scan operation
$filterExpression = [];
$expressionAttributeValues = [];
$expressionAttributeNames = []; // For reserved keywords

if ($title) {
    $filterExpression[] = 'contains(#title, :title)';
    $expressionAttributeValues[':title'] = ['S' => $title];
    $expressionAttributeNames['#title'] = 'title'; // Defining the placeholder for the title attribute
}
if ($year) {
    // Use a placeholder for reserved keywords
    $filterExpression[] = '#yr = :year';
    $expressionAttributeValues[':year'] = ['S' => $year];
    $expressionAttributeNames['#yr'] = 'year'; // Defining the placeholder for the year attribute
}
if ($artist) {
    $filterExpression[] = 'contains(#artist, :artist)';
    $expressionAttributeValues[':artist'] = ['S' => $artist];
    $expressionAttributeNames['#artist'] = 'artist'; // Defining the placeholder for the artist attribute
}

// Execute the scan operation if there are any filter conditions
if (!empty($filterExpression)) {
    try {
        $result = $dynamoDb->scan([
            'TableName' => 'music',
            'FilterExpression' => implode(' AND ', $filterExpression),
            'ExpressionAttributeValues' => $expressionAttributeValues,
            'ExpressionAttributeNames' => $expressionAttributeNames // Include this line
        ]);

        // Check if any items matched the query
        if (!empty($result['Items'])) {
            foreach ($result['Items'] as $item) {
                // Display the music information and the image
                echo "<div class='music-item'>";
                echo "<p>Title: " . $item['title']['S'] . "</p>";
                echo "<p>Artist: " . $item['artist']['S'] . "</p>";
                echo "<p>Year: " . $item['year']['S'] . "</p>";
                echo "<img src='" . $item['img_url']['S'] . "' alt='Artist Image'>";
                echo "<button onclick=\"subscribeToMusic('" . addslashes($item['title']['S']) . "')\">Subscribe</button>";
                echo "</div>";
            }
        } else {
            echo "<p>No result is retrieved. Please query again.</p>";
        }
    } catch (DynamoDbException $e) {
        echo "<p>Error fetching music data: " . $e->getAwsErrorMessage() . "</p>";
    }
} else {
    echo "<p>Please enter search criteria.</p>";
}
?>
