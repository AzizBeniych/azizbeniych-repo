<?php
require 'vendor/autoload.php'; // Ensure the AWS SDK for PHP is installed via Composer

use Aws\DynamoDb\Exception\DynamoDbException;
use Aws\DynamoDb\DynamoDbClient;

// Start the session
session_start();

// Initialize the DynamoDB client with the us-east-1 region
$dynamoDb = new DynamoDbClient([
    'region'  => 'us-east-1',
    'version' => 'latest',
    // Credentials should be provided by IAM roles or environment variables
]);

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password']; // The plain text password from the form

    try {
        // Attempt to retrieve the user from DynamoDB
        $result = $dynamoDb->getItem([
            'TableName' => 'Login',
            'Key' => [
                'email' => [
                    'S' => $email,
                ],
            ],
        ]);

        // Check if user exists and the password matches
        if (isset($result['Item']) && $result['Item']['password']['S'] === $password) {
            // Password is correct, set session variables
            $_SESSION['user_email'] = $email;
            $_SESSION['user_name'] = $result['Item']['user_name']['S']; // Assuming you want to store the username as well

            // Redirect to the main page
            header('Location: index.php');
            exit;
        } else {
            // Authentication failed, redirect to login with error
            header('Location: login.php?error=invalid_credentials');
            exit;
        }
    } catch (DynamoDbException $e) {
        // Handle potential errors gracefully
        error_log('DynamoDB Error: ' . $e->getMessage());
        header('Location: login.php?error=server_error');
        exit;
    }
} else {
    // Form was not submitted via POST, redirect to the login form
    header('Location: login.php');
    exit;
}

?>
