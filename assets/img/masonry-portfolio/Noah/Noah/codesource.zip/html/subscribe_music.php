<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;
use Aws\DynamoDb\Exception\DynamoDbException;

// Initialize the DynamoDB client
$dynamoDb = new DynamoDbClient([
    'region'  => 'us-east-1',
    'version' => 'latest',
]);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Retrieve user email and music title from the AJAX request
$userEmail = $_POST['userEmail'] ?? '';
$musicId = $_POST['musicId'] ?? '';

if ($userEmail && $musicId) {
    try {
        // Check if the subscription already exists
        $existingSubscription = $dynamoDb->query([
            'TableName' => 'Subscriptions',
            'KeyConditionExpression' => 'UserId = :userId and MusicId = :musicId',
            'ExpressionAttributeValues' => [
                ':userId' => ['S' => $userEmail],
                ':musicId' => ['S' => $musicId]
            ]
        ]);

        // If the subscription does not exist, then insert the new item
        if (empty($existingSubscription['Items'])) {
            $result = $dynamoDb->putItem([
                'TableName' => 'Subscriptions',
                'Item' => [
                    'UserId' => ['S' => $userEmail],
                    'MusicId' => ['S' => $musicId], // This assumes MusicId is not a key used to match music items
                   
                ]
            ]);
            echo "Subscription successful";
        } else {
            echo "You have already subscribed to this music.";
        }
    } catch (DynamoDbException $e) {
        // Handle potential DynamoDB errors
        http_response_code(500);
        echo "Error subscribing to music: " . $e->getMessage();
    }
} else {
    http_response_code(400);
    echo "Invalid request";
}
?>
