<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;
use Aws\DynamoDb\Exception\DynamoDbException;

session_start();

// Initialize the DynamoDB client
$dynamoDb = new DynamoDbClient([
    'region'  => 'us-east-1',
    'version' => 'latest',
]);

$userEmail = $_SESSION['user_email'] ?? null;

// Function to fetch user's subscriptions
function fetchUserSubscriptions($dynamoDb, $userEmail) {
    $subscriptions = [];
    try {
        $result = $dynamoDb->query([
            'TableName' => 'Subscriptions',
            'KeyConditionExpression' => 'UserId = :userId',
            'ExpressionAttributeValues' => [
                ':userId' => ['S' => $userEmail]
            ]
        ]);

        foreach ($result['Items'] as $item) {
            $subscriptions[] = $item['MusicId']['S']; // Assuming 'MusicId' corresponds to 'title' in 'music' table
        }
    } catch (DynamoDbException $e) {
        error_log("Error fetching user subscriptions: " . $e->getMessage());
        // Handle error appropriately
    }
    return $subscriptions;
}

$subscriptions = fetchUserSubscriptions($dynamoDb, $userEmail);

// Retrieve search criteria
$title = $_GET['title'] ?? null;
$year = $_GET['year'] ?? null;
$artist = $_GET['artist'] ?? null;

// Constructing a filter expression for the scan operation
$filterExpression = [];
$expressionAttributeValues = [];
if ($title) {
    $filterExpression[] = 'contains(title, :title)';
    $expressionAttributeValues[':title'] = ['S' => $title];
}
if ($year) {
    $filterExpression[] = 'year = :year';
    $expressionAttributeValues[':year'] = ['S' => $year];
}
if ($artist) {
    $filterExpression[] = 'contains(artist, :artist)';
    $expressionAttributeValues[':artist'] = ['S' => $artist];
}

// Execute the scan operation if there are any filter conditions
if (!empty($filterExpression)) {
    try {
        $result = $dynamoDb->scan([
            'TableName' => 'music',
            'FilterExpression' => implode(' AND ', $filterExpression),
            'ExpressionAttributeValues' => $expressionAttributeValues
        ]);

        // Check if any items matched the query
        if (!empty($result['Items'])) {
            foreach ($result['Items'] as $item) {
                if (in_array($item['title']['S'], $subscriptions)) {
                    continue; // Skip this item if the user is already subscribed
                }

                // Display the music information and the image
                echo "<div class='music-item'>";
                echo "<p>Title: " . $item['title']['S'] . "</p>";
                echo "<p>Artist: " . $item['artist']['S'] . "</p>";
                echo "<p>Year: " . $item['year']['S'] . "</p>";
                echo "<img src='" . $item['img_url']['S'] . "' alt='Artist Image'>";
                echo "<button onclick=\"subscribeToMusic('" . addslashes($item['title']['S']) . "')\">Subscribe</button>";
                echo "</div>";
            }
        } else {
            echo "<p>No result is retrieved. Please query again.</p>";
        }
    } catch (Exception $e) {
        echo "<p>Error fetching music data: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>Please enter search criteria.</p>";
}
?>
