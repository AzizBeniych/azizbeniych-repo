<?php
require 'vendor/autoload.php'; // Ensure the AWS SDK for PHP is installed via Composer

use Aws\DynamoDb\Exception\DynamoDbException;
use Aws\DynamoDb\DynamoDbClient;

// Start the session
session_start();

// Initialize the DynamoDB client
$dynamoDb = new DynamoDbClient([
    'region'  => 'us-east-1', // e.g., us-west-2
    'version' => 'latest',
    // Credentials should be provided by IAM roles or environment variables
]);

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password']; // The plain text password from the form

    try {
        // Check if user already exists
        $result = $dynamoDb->getItem([
            'TableName' => 'Login',
            'Key' => [
                'email' => [
                    'S' => $email,
                ],
            ],
        ]);

        if (!empty($result['Item'])) {
            echo "<p id='errormessage'>User already exists.</p>";
        } else {
            // Store the new user with the plain text password
            $dynamoDb->putItem([
                'TableName' => 'Login',
                'Item' => [
                    'email' => [
                        'S' => $email,
                    ],
                    'user_name' => [
                        'S' => $username,
                    ],
                    'password' => [
                        'S' => $password, // Plain text password stored directly
                    ],
                ],
            ]);

            // Redirect to login page or inform the user
            header('Location: login.php?success=registered');
            exit;
        }
    } catch (DynamoDbException $e) {
        // Handle DynamoDB specific errors gracefully
        error_log('DynamoDB Error: ' . $e->getMessage());
        echo "<p id='errormessage'>There was an error processing your registration.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Make sure this path is correct -->
</head>
<body>

<div class="register-container">
    <h2>Register</h2>
    <form method="post" action="register.php">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Login here</a>.</p>
</div>
<style>
    .register-container{
    margin-left: 376px;
    margin-top: 110px;
}
#errormessage {
    color: red;
    position: relative;
    left: 377px;
    top: 80px;
    background-color: #fff;
    padding: 20px;
    width: 347px;
}
</style>
</body>
</html>
