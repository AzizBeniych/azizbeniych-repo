<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;

session_start();

$dynamoDb = new DynamoDbClient([
    'region'  => 'us-east-1',
    'version' => 'latest',
]);

$userEmail = $_POST['userEmail'] ?? null;
$musicId = $_POST['musicId'] ?? null;

if (!$userEmail || !$musicId) {
    http_response_code(400);
    echo "Invalid request: Missing userEmail or musicId.";
    exit;
}

try {
    $result = $dynamoDb->deleteItem([
        'TableName' => 'Subscriptions',
        'Key' => [
            'UserId' => ['S' => $userEmail],
            'MusicId' => ['S' => $musicId]
        ]
    ]);
    echo "Subscription deleted successfully.";
} catch (Aws\DynamoDb\Exception\DynamoDbException $e) {
    error_log("DynamoDB Error: " . $e->getMessage());
    http_response_code(500);
    echo "Error deleting subscription: " . $e->getMessage();
}
?>
